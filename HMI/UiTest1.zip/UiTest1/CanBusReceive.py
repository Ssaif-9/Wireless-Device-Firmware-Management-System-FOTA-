import can
import time

can_interface = 'can0'
bus = can.interface.Bus(can_interface, bustype='socketcan',bitrate=500000)
def RecieveFromCan():
    try:
        bus.recv()
        return True
    except can.CanError:
        return False