# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'interfacecYZFoG.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

from Custom_Widgets.Widgets import QCustomSlideMenu
from Custom_Widgets.Widgets import QStackedWidget

import resources_rc

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(800, 600)
        MainWindow.setStyleSheet(u"*{\n"
"  border:none;\n"
"  background-color:transparent;\n"
"  background:transparent;\n"
"  padding:0;\n"
"  margin:0;\n"
"  color:#fff;\n"
"}\n"
"#centralwidget{\n"
"  background-color:#344955;\n"
"}\n"
"#LeftMenuSubContainer{\n"
"  background-color:#50727B;\n"
"}\n"
"#LeftMenuSubContainer QPushButton{\n"
"  text-align:left;\n"
"  padding: 2px 10px;\n"
"  border-top-left-radius:10px;\n"
"  border-bottom-left-radius:10px;\n"
"}\n"
"#frame_4{\n"
"  background-color:#50727B;\n"
"}\n"
"#CenterMenuSubContainer{\n"
"   background-color:#2c313c;\n"
"}\n"
"#headerContainer{\n"
"  background-color:#2c313c;\n"
"}")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.centralwidget.setStyleSheet(u"")
        self.horizontalLayout = QHBoxLayout(self.centralwidget)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.LeftMenuContainer = QCustomSlideMenu(self.centralwidget)
        self.LeftMenuContainer.setObjectName(u"LeftMenuContainer")
        self.LeftMenuContainer.setMaximumSize(QSize(45, 16777215))
        self.verticalLayout = QVBoxLayout(self.LeftMenuContainer)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.LeftMenuSubContainer = QWidget(self.LeftMenuContainer)
        self.LeftMenuSubContainer.setObjectName(u"LeftMenuSubContainer")
        self.verticalLayout_2 = QVBoxLayout(self.LeftMenuSubContainer)
        self.verticalLayout_2.setSpacing(0)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(5, 0, 0, 0)
        self.frame = QFrame(self.LeftMenuSubContainer)
        self.frame.setObjectName(u"frame")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_2 = QHBoxLayout(self.frame)
        self.horizontalLayout_2.setSpacing(0)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.MenuBar = QPushButton(self.frame)
        self.MenuBar.setObjectName(u"MenuBar")
        self.MenuBar.setStyleSheet(u"")
        icon = QIcon()
        icon.addFile(u":/Icons/Icons/align-justify.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.MenuBar.setIcon(icon)
        self.MenuBar.setIconSize(QSize(24, 24))

        self.horizontalLayout_2.addWidget(self.MenuBar)


        self.verticalLayout_2.addWidget(self.frame, 0, Qt.AlignTop)

        self.frame_2 = QFrame(self.LeftMenuSubContainer)
        self.frame_2.setObjectName(u"frame_2")
        sizePolicy = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.frame_2.sizePolicy().hasHeightForWidth())
        self.frame_2.setSizePolicy(sizePolicy)
        self.frame_2.setFrameShape(QFrame.StyledPanel)
        self.frame_2.setFrameShadow(QFrame.Raised)
        self.verticalLayout_3 = QVBoxLayout(self.frame_2)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(0, 10, 0, 10)
        self.Home = QPushButton(self.frame_2)
        self.Home.setObjectName(u"Home")
        icon1 = QIcon()
        icon1.addFile(u":/Icons/Icons/home.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.Home.setIcon(icon1)
        self.Home.setIconSize(QSize(24, 24))

        self.verticalLayout_3.addWidget(self.Home)

        self.DataAnalysis = QPushButton(self.frame_2)
        self.DataAnalysis.setObjectName(u"DataAnalysis")
        icon2 = QIcon()
        icon2.addFile(u":/Icons/Icons/list.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.DataAnalysis.setIcon(icon2)
        self.DataAnalysis.setIconSize(QSize(24, 24))

        self.verticalLayout_3.addWidget(self.DataAnalysis)

        self.Reports = QPushButton(self.frame_2)
        self.Reports.setObjectName(u"Reports")
        icon3 = QIcon()
        icon3.addFile(u":/Icons/Icons/printer.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.Reports.setIcon(icon3)
        self.Reports.setIconSize(QSize(24, 24))

        self.verticalLayout_3.addWidget(self.Reports)


        self.verticalLayout_2.addWidget(self.frame_2, 0, Qt.AlignTop)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_2.addItem(self.verticalSpacer)

        self.frame_3 = QFrame(self.LeftMenuSubContainer)
        self.frame_3.setObjectName(u"frame_3")
        self.frame_3.setFrameShape(QFrame.StyledPanel)
        self.frame_3.setFrameShadow(QFrame.Raised)
        self.verticalLayout_4 = QVBoxLayout(self.frame_3)
        self.verticalLayout_4.setSpacing(0)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(0, 10, 0, 10)
        self.Settings = QPushButton(self.frame_3)
        self.Settings.setObjectName(u"Settings")
        icon4 = QIcon()
        icon4.addFile(u":/Icons/Icons/settings.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.Settings.setIcon(icon4)
        self.Settings.setIconSize(QSize(24, 24))

        self.verticalLayout_4.addWidget(self.Settings)

        self.Information = QPushButton(self.frame_3)
        self.Information.setObjectName(u"Information")
        icon5 = QIcon()
        icon5.addFile(u":/Icons/Icons/info.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.Information.setIcon(icon5)
        self.Information.setIconSize(QSize(24, 24))

        self.verticalLayout_4.addWidget(self.Information)

        self.Help = QPushButton(self.frame_3)
        self.Help.setObjectName(u"Help")
        icon6 = QIcon()
        icon6.addFile(u":/Icons/Icons/help-circle.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.Help.setIcon(icon6)
        self.Help.setIconSize(QSize(24, 24))

        self.verticalLayout_4.addWidget(self.Help)


        self.verticalLayout_2.addWidget(self.frame_3, 0, Qt.AlignBottom)


        self.verticalLayout.addWidget(self.LeftMenuSubContainer, 0, Qt.AlignLeft)


        self.horizontalLayout.addWidget(self.LeftMenuContainer, 0, Qt.AlignLeft)

        self.CenterMenuContainer = QCustomSlideMenu(self.centralwidget)
        self.CenterMenuContainer.setObjectName(u"CenterMenuContainer")
        self.CenterMenuContainer.setMinimumSize(QSize(200, 0))
        self.verticalLayout_5 = QVBoxLayout(self.CenterMenuContainer)
        self.verticalLayout_5.setSpacing(0)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.verticalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.CenterMenuSubContainer = QWidget(self.CenterMenuContainer)
        self.CenterMenuSubContainer.setObjectName(u"CenterMenuSubContainer")
        self.CenterMenuSubContainer.setMinimumSize(QSize(200, 0))
        self.verticalLayout_6 = QVBoxLayout(self.CenterMenuSubContainer)
        self.verticalLayout_6.setSpacing(0)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.verticalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.frame_4 = QFrame(self.CenterMenuSubContainer)
        self.frame_4.setObjectName(u"frame_4")
        self.frame_4.setFrameShape(QFrame.StyledPanel)
        self.frame_4.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_3 = QHBoxLayout(self.frame_4)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.label = QLabel(self.frame_4)
        self.label.setObjectName(u"label")
        self.label.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_3.addWidget(self.label)

        self.CloseCenterWindow = QPushButton(self.frame_4)
        self.CloseCenterWindow.setObjectName(u"CloseCenterWindow")
        icon7 = QIcon()
        icon7.addFile(u":/Icons/Icons/x-circle.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.CloseCenterWindow.setIcon(icon7)
        self.CloseCenterWindow.setIconSize(QSize(24, 24))

        self.horizontalLayout_3.addWidget(self.CloseCenterWindow, 0, Qt.AlignRight)


        self.verticalLayout_6.addWidget(self.frame_4, 0, Qt.AlignTop)

        self.LeftPages = QStackedWidget(self.CenterMenuSubContainer)
        self.LeftPages.setObjectName(u"LeftPages")
        self.LeftPages.setMinimumSize(QSize(0, 0))
        self.SettingsPage = QWidget()
        self.SettingsPage.setObjectName(u"SettingsPage")
        self.verticalLayout_7 = QVBoxLayout(self.SettingsPage)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.label_2 = QLabel(self.SettingsPage)
        self.label_2.setObjectName(u"label_2")
        font = QFont()
        font.setPointSize(13)
        self.label_2.setFont(font)
        self.label_2.setAlignment(Qt.AlignCenter)

        self.verticalLayout_7.addWidget(self.label_2)

        self.LeftPages.addWidget(self.SettingsPage)
        self.HelpPage = QWidget()
        self.HelpPage.setObjectName(u"HelpPage")
        self.verticalLayout_9 = QVBoxLayout(self.HelpPage)
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.label_4 = QLabel(self.HelpPage)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setFont(font)
        self.label_4.setAlignment(Qt.AlignCenter)

        self.verticalLayout_9.addWidget(self.label_4)

        self.LeftPages.addWidget(self.HelpPage)
        self.InfoPage = QWidget()
        self.InfoPage.setObjectName(u"InfoPage")
        self.verticalLayout_8 = QVBoxLayout(self.InfoPage)
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.label_3 = QLabel(self.InfoPage)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setFont(font)
        self.label_3.setAlignment(Qt.AlignCenter)

        self.verticalLayout_8.addWidget(self.label_3)

        self.LeftPages.addWidget(self.InfoPage)

        self.verticalLayout_6.addWidget(self.LeftPages)


        self.verticalLayout_5.addWidget(self.CenterMenuSubContainer, 0, Qt.AlignLeft)


        self.horizontalLayout.addWidget(self.CenterMenuContainer)

        self.MainBodyContainer = QWidget(self.centralwidget)
        self.MainBodyContainer.setObjectName(u"MainBodyContainer")
        sizePolicy1 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.MainBodyContainer.sizePolicy().hasHeightForWidth())
        self.MainBodyContainer.setSizePolicy(sizePolicy1)
        self.MainBodyContainer.setStyleSheet(u"background-color:#AAD7D9;")
        self.verticalLayout_10 = QVBoxLayout(self.MainBodyContainer)
        self.verticalLayout_10.setSpacing(0)
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.verticalLayout_10.setContentsMargins(0, 0, 0, 100)
        self.headerContainer = QWidget(self.MainBodyContainer)
        self.headerContainer.setObjectName(u"headerContainer")
        self.headerContainer.setAutoFillBackground(False)
        self.headerContainer.setStyleSheet(u"background-color:#50727B;")
        self.horizontalLayout_5 = QHBoxLayout(self.headerContainer)
        self.horizontalLayout_5.setSpacing(0)
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.horizontalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.frame_6 = QFrame(self.headerContainer)
        self.frame_6.setObjectName(u"frame_6")
        self.frame_6.setFrameShape(QFrame.StyledPanel)
        self.frame_6.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_6 = QHBoxLayout(self.frame_6)
        self.horizontalLayout_6.setSpacing(0)
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.horizontalLayout_6.setContentsMargins(11, 11, 11, 11)
        self.moreMenuBtn = QPushButton(self.frame_6)
        self.moreMenuBtn.setObjectName(u"moreMenuBtn")
        icon8 = QIcon()
        icon8.addFile(u":/Icons/Icons/more-horizontal.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.moreMenuBtn.setIcon(icon8)
        self.moreMenuBtn.setIconSize(QSize(24, 24))

        self.horizontalLayout_6.addWidget(self.moreMenuBtn)

        self.ProfileBtn = QPushButton(self.frame_6)
        self.ProfileBtn.setObjectName(u"ProfileBtn")
        icon9 = QIcon()
        icon9.addFile(u":/Icons/Icons/user.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.ProfileBtn.setIcon(icon9)
        self.ProfileBtn.setIconSize(QSize(24, 24))

        self.horizontalLayout_6.addWidget(self.ProfileBtn)


        self.horizontalLayout_5.addWidget(self.frame_6)

        self.frame_7 = QFrame(self.headerContainer)
        self.frame_7.setObjectName(u"frame_7")
        self.frame_7.setFrameShape(QFrame.StyledPanel)
        self.frame_7.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_4 = QHBoxLayout(self.frame_7)
        self.horizontalLayout_4.setSpacing(0)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(11, 11, 11, 11)
        self.minimizeBtn = QPushButton(self.frame_7)
        self.minimizeBtn.setObjectName(u"minimizeBtn")
        icon10 = QIcon()
        icon10.addFile(u":/Icons/Icons/minus.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.minimizeBtn.setIcon(icon10)

        self.horizontalLayout_4.addWidget(self.minimizeBtn)

        self.restoreBtn = QPushButton(self.frame_7)
        self.restoreBtn.setObjectName(u"restoreBtn")
        icon11 = QIcon()
        icon11.addFile(u":/Icons/Icons/square.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.restoreBtn.setIcon(icon11)

        self.horizontalLayout_4.addWidget(self.restoreBtn)

        self.closeBtn = QPushButton(self.frame_7)
        self.closeBtn.setObjectName(u"closeBtn")
        icon12 = QIcon()
        icon12.addFile(u":/Icons/Icons/x.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.closeBtn.setIcon(icon12)

        self.horizontalLayout_4.addWidget(self.closeBtn)


        self.horizontalLayout_5.addWidget(self.frame_7)


        self.verticalLayout_10.addWidget(self.headerContainer, 0, Qt.AlignTop)

        self.mainBodyContent = QWidget(self.MainBodyContainer)
        self.mainBodyContent.setObjectName(u"mainBodyContent")
        sizePolicy2 = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.mainBodyContent.sizePolicy().hasHeightForWidth())
        self.mainBodyContent.setSizePolicy(sizePolicy2)
        self.mainBodyContent.setStyleSheet(u"background-color:#8CB9BD;")
        self.horizontalLayout_7 = QHBoxLayout(self.mainBodyContent)
        self.horizontalLayout_7.setSpacing(0)
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.horizontalLayout_7.setContentsMargins(0, 0, 0, 0)
        self.mainContensContainer = QWidget(self.mainBodyContent)
        self.mainContensContainer.setObjectName(u"mainContensContainer")
        self.mainContensContainer.setStyleSheet(u"background-color:#AAD7D9;")
        self.verticalLayout_15 = QVBoxLayout(self.mainContensContainer)
        self.verticalLayout_15.setObjectName(u"verticalLayout_15")
        self.MainPages = QStackedWidget(self.mainContensContainer)
        self.MainPages.setObjectName(u"MainPages")
        self.MainPages.setStyleSheet(u"background-color:#AAD7D9;")
        self.HomePage = QWidget()
        self.HomePage.setObjectName(u"HomePage")
        self.verticalLayout_16 = QVBoxLayout(self.HomePage)
        self.verticalLayout_16.setObjectName(u"verticalLayout_16")
        self.label_8 = QLabel(self.HomePage)
        self.label_8.setObjectName(u"label_8")
        self.label_8.setFont(font)
        self.label_8.setAlignment(Qt.AlignCenter)

        self.verticalLayout_16.addWidget(self.label_8)

        self.MainPages.addWidget(self.HomePage)
        self.DataAnalysisPage = QWidget()
        self.DataAnalysisPage.setObjectName(u"DataAnalysisPage")
        self.verticalLayout_17 = QVBoxLayout(self.DataAnalysisPage)
        self.verticalLayout_17.setObjectName(u"verticalLayout_17")
        self.label_9 = QLabel(self.DataAnalysisPage)
        self.label_9.setObjectName(u"label_9")
        self.label_9.setFont(font)
        self.label_9.setAlignment(Qt.AlignCenter)

        self.verticalLayout_17.addWidget(self.label_9)

        self.MainPages.addWidget(self.DataAnalysisPage)
        self.ReportsPage = QWidget()
        self.ReportsPage.setObjectName(u"ReportsPage")
        self.verticalLayout_18 = QVBoxLayout(self.ReportsPage)
        self.verticalLayout_18.setObjectName(u"verticalLayout_18")
        self.DiagnosticTextBox = QTextEdit(self.ReportsPage)
        self.DiagnosticTextBox.setObjectName(u"DiagnosticTextBox")
        self.DiagnosticTextBox.setStyleSheet(u"background-color: rgb(243, 255, 246);")

        self.verticalLayout_18.addWidget(self.DiagnosticTextBox)

        self.SendBtn = QPushButton(self.ReportsPage)
        self.SendBtn.setObjectName(u"SendBtn")
        self.SendBtn.setStyleSheet(u"background-color:#50727B; border-radius:20px;")

        self.verticalLayout_18.addWidget(self.SendBtn)

        self.CancelBtn = QPushButton(self.ReportsPage)
        self.CancelBtn.setObjectName(u"CancelBtn")
        self.CancelBtn.setStyleSheet(u"background-color:#50727B; border-radius:20px;")

        self.verticalLayout_18.addWidget(self.CancelBtn)

        self.label_10 = QLabel(self.ReportsPage)
        self.label_10.setObjectName(u"label_10")
        self.label_10.setFont(font)
        self.label_10.setAlignment(Qt.AlignCenter)

        self.verticalLayout_18.addWidget(self.label_10)

        self.MainPages.addWidget(self.ReportsPage)

        self.verticalLayout_15.addWidget(self.MainPages)


        self.horizontalLayout_7.addWidget(self.mainContensContainer)

        self.rightMenuContainer = QCustomSlideMenu(self.mainBodyContent)
        self.rightMenuContainer.setObjectName(u"rightMenuContainer")
        self.rightMenuContainer.setMinimumSize(QSize(200, 0))
        self.rightMenuContainer.setStyleSheet(u"background-color:#2c313c;")
        self.verticalLayout_11 = QVBoxLayout(self.rightMenuContainer)
        self.verticalLayout_11.setSpacing(5)
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.verticalLayout_11.setContentsMargins(5, 5, 5, 5)
        self.frame_5 = QFrame(self.rightMenuContainer)
        self.frame_5.setObjectName(u"frame_5")
        self.frame_5.setStyleSheet(u"background-color:#50727B; border-radius:10px;")
        self.frame_5.setFrameShape(QFrame.StyledPanel)
        self.frame_5.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_8 = QHBoxLayout(self.frame_5)
        self.horizontalLayout_8.setSpacing(7)
        self.horizontalLayout_8.setObjectName(u"horizontalLayout_8")
        self.horizontalLayout_8.setContentsMargins(11, 11, 11, 11)
        self.label_5 = QLabel(self.frame_5)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_8.addWidget(self.label_5)

        self.CloseRightMenuBtn = QPushButton(self.frame_5)
        self.CloseRightMenuBtn.setObjectName(u"CloseRightMenuBtn")
        self.CloseRightMenuBtn.setIcon(icon7)
        self.CloseRightMenuBtn.setIconSize(QSize(24, 24))

        self.horizontalLayout_8.addWidget(self.CloseRightMenuBtn, 0, Qt.AlignRight)


        self.verticalLayout_11.addWidget(self.frame_5)

        self.rightMenuSubContainer = QWidget(self.rightMenuContainer)
        self.rightMenuSubContainer.setObjectName(u"rightMenuSubContainer")
        self.rightMenuSubContainer.setMinimumSize(QSize(200, 0))
        self.rightMenuSubContainer.setStyleSheet(u"background-color:#2c313c;")
        self.verticalLayout_12 = QVBoxLayout(self.rightMenuSubContainer)
        self.verticalLayout_12.setSpacing(0)
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.verticalLayout_12.setContentsMargins(0, 0, 0, 0)
        self.RightPages = QStackedWidget(self.rightMenuSubContainer)
        self.RightPages.setObjectName(u"RightPages")
        self.ProfilePage = QWidget()
        self.ProfilePage.setObjectName(u"ProfilePage")
        self.verticalLayout_13 = QVBoxLayout(self.ProfilePage)
        self.verticalLayout_13.setObjectName(u"verticalLayout_13")
        self.label_6 = QLabel(self.ProfilePage)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setFont(font)
        self.label_6.setAlignment(Qt.AlignCenter)

        self.verticalLayout_13.addWidget(self.label_6)

        self.RightPages.addWidget(self.ProfilePage)
        self.MorePage = QWidget()
        self.MorePage.setObjectName(u"MorePage")
        self.verticalLayout_14 = QVBoxLayout(self.MorePage)
        self.verticalLayout_14.setObjectName(u"verticalLayout_14")
        self.label_7 = QLabel(self.MorePage)
        self.label_7.setObjectName(u"label_7")
        self.label_7.setFont(font)
        self.label_7.setAlignment(Qt.AlignCenter)

        self.verticalLayout_14.addWidget(self.label_7)

        self.RightPages.addWidget(self.MorePage)

        self.verticalLayout_12.addWidget(self.RightPages)


        self.verticalLayout_11.addWidget(self.rightMenuSubContainer, 0, Qt.AlignRight)


        self.horizontalLayout_7.addWidget(self.rightMenuContainer)


        self.verticalLayout_10.addWidget(self.mainBodyContent)

        self.popupNotificationContainer = QCustomSlideMenu(self.MainBodyContainer)
        self.popupNotificationContainer.setObjectName(u"popupNotificationContainer")
        sizePolicy.setHeightForWidth(self.popupNotificationContainer.sizePolicy().hasHeightForWidth())
        self.popupNotificationContainer.setSizePolicy(sizePolicy)
        self.popupNotificationContainer.setMinimumSize(QSize(0, 0))
        self.verticalLayout_19 = QVBoxLayout(self.popupNotificationContainer)
        self.verticalLayout_19.setSpacing(0)
        self.verticalLayout_19.setObjectName(u"verticalLayout_19")
        self.verticalLayout_19.setContentsMargins(5, 5, 5, 5)
        self.popupNotificationSubContainer = QWidget(self.popupNotificationContainer)
        self.popupNotificationSubContainer.setObjectName(u"popupNotificationSubContainer")
        sizePolicy.setHeightForWidth(self.popupNotificationSubContainer.sizePolicy().hasHeightForWidth())
        self.popupNotificationSubContainer.setSizePolicy(sizePolicy)
        self.popupNotificationSubContainer.setStyleSheet(u"background-color:#50727B; border-radius:10px;")
        self.verticalLayout_20 = QVBoxLayout(self.popupNotificationSubContainer)
        self.verticalLayout_20.setObjectName(u"verticalLayout_20")
        self.label_12 = QLabel(self.popupNotificationSubContainer)
        self.label_12.setObjectName(u"label_12")
        font1 = QFont()
        font1.setPointSize(10)
        font1.setBold(True)
        font1.setWeight(75)
        self.label_12.setFont(font1)

        self.verticalLayout_20.addWidget(self.label_12, 0, Qt.AlignLeft)

        self.CloseBtnNotficiation = QPushButton(self.popupNotificationSubContainer)
        self.CloseBtnNotficiation.setObjectName(u"CloseBtnNotficiation")
        icon13 = QIcon()
        icon13.addFile(u":/Icons/Icons/x-octagon.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.CloseBtnNotficiation.setIcon(icon13)
        self.CloseBtnNotficiation.setIconSize(QSize(24, 24))

        self.verticalLayout_20.addWidget(self.CloseBtnNotficiation, 0, Qt.AlignRight)

        self.frame_8 = QFrame(self.popupNotificationSubContainer)
        self.frame_8.setObjectName(u"frame_8")
        self.frame_8.setFrameShape(QFrame.StyledPanel)
        self.frame_8.setFrameShadow(QFrame.Raised)
        self.verticalLayout_21 = QVBoxLayout(self.frame_8)
        self.verticalLayout_21.setObjectName(u"verticalLayout_21")
        self.label_11 = QLabel(self.frame_8)
        self.label_11.setObjectName(u"label_11")
        sizePolicy1.setHeightForWidth(self.label_11.sizePolicy().hasHeightForWidth())
        self.label_11.setSizePolicy(sizePolicy1)
        font2 = QFont()
        font2.setPointSize(10)
        self.label_11.setFont(font2)
        self.label_11.setAlignment(Qt.AlignCenter)

        self.verticalLayout_21.addWidget(self.label_11)

        self.YesResponse = QPushButton(self.frame_8)
        self.YesResponse.setObjectName(u"YesResponse")

        self.verticalLayout_21.addWidget(self.YesResponse)

        self.NoResponse = QPushButton(self.frame_8)
        self.NoResponse.setObjectName(u"NoResponse")

        self.verticalLayout_21.addWidget(self.NoResponse)

        self.NotNowResponse = QPushButton(self.frame_8)
        self.NotNowResponse.setObjectName(u"NotNowResponse")

        self.verticalLayout_21.addWidget(self.NotNowResponse)


        self.verticalLayout_20.addWidget(self.frame_8)


        self.verticalLayout_19.addWidget(self.popupNotificationSubContainer)


        self.verticalLayout_10.addWidget(self.popupNotificationContainer)


        self.horizontalLayout.addWidget(self.MainBodyContainer)

        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)

        self.LeftPages.setCurrentIndex(2)
        self.RightPages.setCurrentIndex(1)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
#if QT_CONFIG(tooltip)
        self.MenuBar.setToolTip(QCoreApplication.translate("MainWindow", u"Menu Bar", None))
#endif // QT_CONFIG(tooltip)
        self.MenuBar.setText("")
#if QT_CONFIG(tooltip)
        self.Home.setToolTip(QCoreApplication.translate("MainWindow", u"Home", None))
#endif // QT_CONFIG(tooltip)
        self.Home.setText(QCoreApplication.translate("MainWindow", u"Home", None))
#if QT_CONFIG(tooltip)
        self.DataAnalysis.setToolTip(QCoreApplication.translate("MainWindow", u"Data Analysis", None))
#endif // QT_CONFIG(tooltip)
        self.DataAnalysis.setText(QCoreApplication.translate("MainWindow", u"Data Analysis", None))
#if QT_CONFIG(tooltip)
        self.Reports.setToolTip(QCoreApplication.translate("MainWindow", u"Reports", None))
#endif // QT_CONFIG(tooltip)
        self.Reports.setText(QCoreApplication.translate("MainWindow", u"Reports", None))
#if QT_CONFIG(tooltip)
        self.Settings.setToolTip(QCoreApplication.translate("MainWindow", u"Settings", None))
#endif // QT_CONFIG(tooltip)
        self.Settings.setText(QCoreApplication.translate("MainWindow", u"Settings", None))
#if QT_CONFIG(tooltip)
        self.Information.setToolTip(QCoreApplication.translate("MainWindow", u"Information about the app", None))
#endif // QT_CONFIG(tooltip)
        self.Information.setText(QCoreApplication.translate("MainWindow", u"Information", None))
#if QT_CONFIG(tooltip)
        self.Help.setToolTip(QCoreApplication.translate("MainWindow", u"Help", None))
#endif // QT_CONFIG(tooltip)
        self.Help.setText(QCoreApplication.translate("MainWindow", u"Help", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"More Menu", None))
#if QT_CONFIG(tooltip)
        self.CloseCenterWindow.setToolTip(QCoreApplication.translate("MainWindow", u"close Menu", None))
#endif // QT_CONFIG(tooltip)
        self.CloseCenterWindow.setText("")
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"Settings", None))
        self.label_4.setText(QCoreApplication.translate("MainWindow", u"Help", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"Information", None))
#if QT_CONFIG(tooltip)
        self.moreMenuBtn.setToolTip(QCoreApplication.translate("MainWindow", u"More", None))
#endif // QT_CONFIG(tooltip)
        self.moreMenuBtn.setText("")
#if QT_CONFIG(tooltip)
        self.ProfileBtn.setToolTip(QCoreApplication.translate("MainWindow", u"Profile", None))
#endif // QT_CONFIG(tooltip)
        self.ProfileBtn.setText("")
#if QT_CONFIG(tooltip)
        self.minimizeBtn.setToolTip(QCoreApplication.translate("MainWindow", u"minimize window", None))
#endif // QT_CONFIG(tooltip)
        self.minimizeBtn.setText("")
#if QT_CONFIG(tooltip)
        self.restoreBtn.setToolTip(QCoreApplication.translate("MainWindow", u"Restore window", None))
#endif // QT_CONFIG(tooltip)
        self.restoreBtn.setText("")
#if QT_CONFIG(tooltip)
        self.closeBtn.setToolTip(QCoreApplication.translate("MainWindow", u"close window", None))
#endif // QT_CONFIG(tooltip)
        self.closeBtn.setText("")
        self.label_8.setText(QCoreApplication.translate("MainWindow", u"Home", None))
        self.label_9.setText(QCoreApplication.translate("MainWindow", u"Data Analysis", None))
        self.SendBtn.setText(QCoreApplication.translate("MainWindow", u"Send", None))
        self.CancelBtn.setText(QCoreApplication.translate("MainWindow", u"Cancel", None))
        self.label_10.setText("")
        self.label_5.setText(QCoreApplication.translate("MainWindow", u"Right Menu", None))
#if QT_CONFIG(tooltip)
        self.CloseRightMenuBtn.setToolTip(QCoreApplication.translate("MainWindow", u"close Menu", None))
#endif // QT_CONFIG(tooltip)
        self.CloseRightMenuBtn.setText("")
        self.label_6.setText(QCoreApplication.translate("MainWindow", u"Profile", None))
        self.label_7.setText(QCoreApplication.translate("MainWindow", u"More...", None))
        self.label_12.setText(QCoreApplication.translate("MainWindow", u"Notification", None))
#if QT_CONFIG(tooltip)
        self.CloseBtnNotficiation.setToolTip(QCoreApplication.translate("MainWindow", u"close notification", None))
#endif // QT_CONFIG(tooltip)
        self.CloseBtnNotficiation.setText("")
        self.label_11.setText(QCoreApplication.translate("MainWindow", u"There's new update, you want update now?", None))
        self.YesResponse.setText(QCoreApplication.translate("MainWindow", u"Yes", None))
        self.NoResponse.setText(QCoreApplication.translate("MainWindow", u"No", None))
        self.NotNowResponse.setText(QCoreApplication.translate("MainWindow", u"Not Now", None))
    # retranslateUi

