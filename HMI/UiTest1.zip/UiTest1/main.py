import os 
import sys
#import GUI file
from ui_interface import * 
from Custom_Widgets.Widgets import *
#from CanBusReceive import * 
#from CanBusSend import *
##main window class
class MainWindow(QMainWindow):
	"""docstring for MainWindow"""
	def __init__(self, parent=None):
		QMainWindow.__init__(self)
		self.ui = Ui_MainWindow()
		self.ui.setupUi(self)
		loadJsonStyle(self, self.ui)
		#show window 
		self.show()
		# EXPAND center window SIZE
		self.ui.Settings.clicked.connect(lambda : self.ui.CenterMenuContainer.expandMenu())
		self.ui.Information.clicked.connect(lambda : self.ui.CenterMenuContainer.expandMenu())
		self.ui.Help.clicked.connect(lambda : self.ui.CenterMenuContainer.expandMenu())
		#close center window
		self.ui.CloseCenterWindow.clicked.connect(lambda : self.ui.CenterMenuContainer.collapseMenu())
		# EXPAND right window SIZE
		self.ui.moreMenuBtn.clicked.connect(lambda : self.ui.rightMenuContainer.expandMenu())
		self.ui.ProfileBtn.clicked.connect(lambda : self.ui.rightMenuContainer.expandMenu())
		#close right window
		self.ui.CloseRightMenuBtn.clicked.connect(lambda : self.ui.rightMenuContainer.collapseMenu())
		#close pop up notification window
		self.ui.CloseBtnNotficiation.clicked.connect(lambda : self.ui.popupNotificationContainer.collapseMenu())

## Execute App
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())

    #END		