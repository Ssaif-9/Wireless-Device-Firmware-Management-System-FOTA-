import os 
import sys
#import GUI file
from ui_interface import * 
from Custom_Widgets.Widgets import *
from PyQt5.QtWidgets import QTableWidget, QTableWidgetItem
from PySide2.QtCore import QSize
from PySide2.QtWidgets import QTableWidgetItem, QWidget, QPushButton, QHBoxLayout
#from CanBusReceive import *
#from CanBusSend import *

##main window class
class MainWindow(QMainWindow):
	def write_char(self,place,ch):
		textboxValue = place.toPlainText()
		place.setHtml(textboxValue+ch)
	def remove_char(self,place):
		textboxValue = place.toPlainText()
		place.setHtml(textboxValue[:-1])
	"""docstring for MainWindow"""
	def get_text(self,place):
		textboxValue = place.toPlainText()
		print(textboxValue)
	def CreateButton(self):
		UpdateNowButton = QPushButton()
		UpdateNowButton.setText("Update Now")
		UpdateNowButton.setStyleSheet("background-color:#50727B; border-radius:10px; font-size:15px;")
		UpdateNowButton.clicked.connect(self.YesResponseClicked)
		widget = QWidget()
		layout = QHBoxLayout(widget)
		layout.addWidget(UpdateNowButton)
		widget.setLayout(layout)
		table_item = QTableWidgetItem()
		table_item.setSizeHint(widget.sizeHint())
		self.ui.DataAnalysisTable.setItem(self.row, 1 , table_item)
		self.ui.DataAnalysisTable.setCellWidget(self.row,1,widget)
	def loadData(self):
		update=[{"Update":"Update 1","Status":"Updated"}]
		self.ui.DataAnalysisTable.setRowCount(5)
		for everyUpdate in update:
			self.ui.DataAnalysisTable.setItem(self.row , 0 , QtWidgets.QTableWidgetItem(everyUpdate["Update"]))
			self.ui.DataAnalysisTable.setItem(self.row , 1 , QtWidgets.QTableWidgetItem(everyUpdate["Status"]))
			self.row += 1
	def loadDataNotNow(self):
		NotNowUpdate=[{"Update":"Update 2","Status":self.CreateButton()}]
		self.ui.DataAnalysisTable.setRowCount(5)
		for everyNotNowUpdate in NotNowUpdate:
			self.ui.DataAnalysisTable.setItem(self.row , 0 , QtWidgets.QTableWidgetItem(everyNotNowUpdate["Update"]))
			self.ui.DataAnalysisTable.setItem(self.row , 1 , QtWidgets.QTableWidgetItem(everyNotNowUpdate["Status"]))
			self.row +=1
	def DataAnalaysisBtnFunction(self):
		if (RecieveFromCan() == 'u'):
			self.ui.popupNotificationContainer.expandMenu()
	def YesResponseClicked(self):
		self.ui.popupNotificationContainer.collapseMenu()
		#SendToCan('y')
		if (RecieveFromCan()=='c'):
			self.ui.CriticalModeNotification.expandMenu()
			self.loadDataNotNow()
			self.ui.CriticalModeNotification.collapseMenu()
		else:
			self.ui.DownloadingNotification.expandMenu()
		print('y')
		if (RecieveFromCan() == 'D'):
			self.ui.DownloadingNotification.collapseMenu()
			self.loadData()
	def NotNowRespnseClicked(self):
		self.loadDataNotNow()
	def __init__(self, parent=None):
		QMainWindow.__init__(self)
		self.ui = Ui_MainWindow()
		self.ui.setupUi(self)
		self.row =0
		header = self.ui.DataAnalysisTable.horizontalHeader()
		header.setSectionResizeMode(0, QHeaderView.Stretch)
		header.setSectionResizeMode(1, QHeaderView.Stretch)
		loadJsonStyle(self, self.ui)
		#show window 
		self.show()
		# EXPAND center window SIZE
		self.ui.Settings.clicked.connect(lambda : self.ui.CenterMenuContainer.expandMenu())
		self.ui.Information.clicked.connect(lambda : self.ui.CenterMenuContainer.expandMenu())
		self.ui.Help.clicked.connect(lambda : self.ui.CenterMenuContainer.expandMenu())
		#close center window
		self.ui.CloseCenterWindow.clicked.connect(lambda : self.ui.CenterMenuContainer.collapseMenu())
		# EXPAND right window SIZE
		self.ui.moreMenuBtn.clicked.connect(lambda : self.ui.rightMenuContainer.expandMenu())
		self.ui.ProfileBtn.clicked.connect(lambda : self.ui.rightMenuContainer.expandMenu())
		#close right window
		self.ui.CloseRightMenuBtn.clicked.connect(lambda : self.ui.rightMenuContainer.collapseMenu())
		#write the characters in the keyboard 
		self.ui.one.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'1'))
		self.ui.two.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'2'))
		self.ui.three.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'3'))
		self.ui.four.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'4'))
		self.ui.five.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'5'))
		self.ui.six.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'6'))
		self.ui.seven.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'7'))
		self.ui.eight.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'8'))
		self.ui.nine.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'9'))
		self.ui.zero.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'0'))
		self.ui.A.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'a'))
		self.ui.B.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'b'))
		self.ui.C.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'c'))
		self.ui.D.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'d'))
		self.ui.E.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'e'))
		self.ui.F.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'f'))
		self.ui.G.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'g'))
		self.ui.H.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'h'))
		self.ui.I.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'i'))
		self.ui.J.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'j'))
		self.ui.K.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'k'))
		self.ui.L.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'l'))
		self.ui.M.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'m'))
		self.ui.N.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'n'))
		self.ui.O.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'o'))
		self.ui.P.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'p'))
		self.ui.Q.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'q'))
		self.ui.R.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'r'))
		self.ui.S.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'s'))
		self.ui.T.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'t'))
		self.ui.U.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'u'))
		self.ui.V.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'v'))
		self.ui.W.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'w'))
		self.ui.X.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'x'))
		self.ui.Y.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'y'))
		self.ui.Z.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'z'))
		self.ui.Space.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,' '))
		self.ui.comma.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,','))
		self.ui.dot.clicked.connect(lambda : self.write_char(self.ui.DiagnosticTextBox ,'.'))
		#remove character in the keyboard
		self.ui.BackSpace.clicked.connect(lambda : self.remove_char(self.ui.DiagnosticTextBox))
		#clear the text in textbox
		self.ui.CancelBtn.clicked.connect(lambda : self.ui.DiagnosticTextBox.clear())
		#get the text in text box
		self.ui.SendBtn.clicked.connect(lambda : self.get_text(self.ui.DiagnosticTextBox))
		#insert row in the table widget
		self.ui.SendBtn.clicked.connect(lambda : self.loadDataNotNow())
		self.ui.CancelBtn.clicked.connect(lambda : self.loadData())
		#Yes or Not now response 
		self.ui.YesResponse.clicked.connect(lambda : self.YesResponseClicked())
		self.ui.NotNowResponse.clicked.connect(lambda : self.NotNowRespnseClicked())
		#check the receive from Can 
		#self.ui.DataAnalysis.clicked.connect(lambda : self.DataAnalaysisBtnFunction())
## Execute App
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())

    #END		