import can
import time

can_interface = 'can0'
bus = can.interface.Bus(can_interface, bustype='socketcan', bitrate=500000)

# Define the ID you want to receive messages from
target_id = 0x100
def RecieveFromCan():
    while True:
    # Check if the received message has the desired ID
        if message.arbitration_id == target_id:
            message = bus.recv()
            print("Received message with ID:", message.arbitration_id)
            return (message)    
